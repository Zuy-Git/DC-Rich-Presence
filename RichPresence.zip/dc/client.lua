Citizen.CreateThread(function()
	while true do
		SetDiscordAppId(TÄHÄNAPPID)

		SetDiscordRichPresenceAsset('eisediscord')

--        SetDiscordRichPresenceAssetText('Legion') 
--        ^^ Jos haluat tekstin ison kuvaan alhaalla on silleen että siinä kohdassa näkyy missä on:)
       
        SetDiscordRichPresenceAssetSmall('eisediscord')

--        SetDiscordRichPresenceAssetSmallText('')
--        ^^ Pienenkuvan custom teksti jos haluaa!

        
        
        
        -- Zuy#9582
        
        -- ÄLÄ KOSKE!!!!
        local playerCount = #GetActivePlayers()
        
        -- ÄLÄ KOSKE!!!!
        local playerName = GetPlayerName(PlayerId())

        -- SLOTIT!!
        local maxPlayerSlots = "64"

        -- ÄLÄ KOSKE!!!!
        SetRichPresence(string.format("%s - %s/%s", playerName, playerCount, maxPlayerSlots))

        -- NÄKYY KUVASSA SIJAINTI!!
        SetDiscordRichPresenceAssetText( GetPlayerName(source) .. " on kadulla " .. GetStreetNameFromHashKey(GetStreetNameAtCoord(table.unpack(GetEntityCoords(player))) ))

        -- PIKKU KUVAS NÄKYY HPEET!!
        SetDiscordRichPresenceAssetSmallText("HP: "..(GetEntityHealth(player)-100))

        -- PÄIVITTYY JOKA MINUUTTI!!
		Citizen.Wait(60000)
	end
end)